import RecipeApp from './RecipeApp.js'

new RecipeApp({ $target: document.querySelector('.recipeApp')})